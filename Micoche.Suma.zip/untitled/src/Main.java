public class Main {
    public static void main(String[] args)
    {
        int param1=10;
        int param2=3;
        int param3=5;

        var valor= suma(param1,param2,param3);
        System.out.println(valor);

        coche micoche= new coche();
        micoche.incrementarpuertas();
        System.out.println(micoche.puertas);
    }

    public static int suma (int a, int b, int c) {
        return a + b + c;
    }
}

class coche{
    public int puertas=3;

    public void incrementarpuertas() {
        this.puertas++;
    }
}