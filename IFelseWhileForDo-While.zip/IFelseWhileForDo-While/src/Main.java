public class Main {
    public static void main(String[] args) {
        int num = -1;
        int num2 = 1;
        var estacion = "rojo";

        // Sentencia IF
        if (num > 0) {
            System.out.println("Es positivo");
        } else if (num < 0) {
            System.out.println("Es negativo");
        } else {
            System.out.println("Es cero");
        }

        //Sentencia WHILE
        while (num < 3) {
            num++;
            System.out.println(num);
        }

        //Sentencia DO WHILE
        do {
            System.out.println(num2);
            num2++;
        }
        while (num2 < 3);

        //Sentencia FOR
        for (int numeroFor = 0; numeroFor <= 3; numeroFor++) {
            System.out.println(numeroFor);

        }

        //Switch
        switch (estacion) {
            case "Verano":
                System.out.println("Es verano");
                break;
            case "Invierno":
                System.out.println("Es invierno");
                break;
            case "Otoño":
                System.out.println("Es otoño");
                break;
            case "Primavera":
                System.out.println("Es primavera");
                break;
            default:
                System.out.println("No es una estacion");
        }
    }
}
